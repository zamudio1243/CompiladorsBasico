import  os
class Compilador:
    def __init__(self, nombreArchvio):
        self.archivo= open(nombreArchvio,"r")

    def metodoCar(self):
        return  self.archivo.read(1)

def main():
    file = "RegistroCaracteres.txt"
    comp = Compilador(file)
    x= comp.metodoCar()
    x = comp.metodoCar()
    x = comp.metodoCar()
    print(x)
    x = comp.metodoCar()
    x = comp.metodoCar()
    x = comp.metodoCar()
    print(x)

main()
