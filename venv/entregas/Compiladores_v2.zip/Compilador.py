import  os
class Compilador:
    def __init__(self, nombreArchvio):
        self.archivo= open(nombreArchvio,"r")

    def metodoCar(self):
        return  self.archivo.read(1)
    def generador(self):
        valido = ""
        x = self.metodoCar()
        if(x.isalpha() or x == '_' ):
            valido+=x
            x= self.metodoCar()
            if(x.isalnum() or x == '_'):
                valido+=x
                x = self.metodoCar()
                while(x.isalnum() or x == '_' ):
                    valido+=x
                    x = self.metodoCar()
        return valido
"""    
    def valAlfa(self,x):
        guion = ord(x) == 95
        mayusculas = ord(x) > 64 and ord(x) < 91
        minusculas = ord(x) > 96 and ord(x) < 123
        return guion or mayusculas or minusculas

    def valAlfaNum(self,x):
        guion = ord(x) == 95
        mayusculas = ord(x) > 64 and ord(x) < 91
        minusculas = ord(x) > 96 and ord(x) < 123
        numeros = ord(x) > 47 and ord(x) < 58
        return guion or mayusculas or minusculas or numeros
"""


def main():
    file = "RegistroCaracteres.txt"
    comp = Compilador(file)
    print(comp.generador())
main()
